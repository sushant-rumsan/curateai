import React from 'react'

const ErrorText = ({children}: any) => {
  return <div className='error'>{children}</div>
}

export default ErrorText
