"use client";

import Link from "next/link";
// import { useReadCurateTokenBalanceOf } from "@/hooks/wagmi/contracts"
import { contract } from "@/constants/contract";
import { Search, User, BookmarkIcon } from "lucide-react";
import Disconnect from "./magic/wallet-methods/Disconnect";
import { useMagicState } from "@/app/context/magic.provider";
import { useEffect, useState } from "react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";

export function Navbar() {
  useEffect(() => {
    const user = localStorage.getItem("user");
    setPublicAddress(user as string);
  }, []);

  const [publicAddress, setPublicAddress] = useState<string | null>(null);
  // const { data } = useReadCurateTokenBalanceOf({
  //   address: contract.TOKEN as `0x${string}`,
  //   args: [publicAddress as `0x${string}`],
  // })

  const { token, setToken } = useMagicState();

  return (
    <header className="fixed top-0 left-0 right-0 bg-white border-b border-gray-200 z-50">
      <div className="max-w-[1280px] mx-auto px-4">
        <div className="h-16 flex items-center justify-between">
          <div className="flex items-center gap-8">
            <Link href="/" className="flex items-center gap-2">
              <span className="font-serif font-bold text-xl text-gray-900">
                CurateAI
              </span>
            </Link>
            <nav className="hidden md:flex items-center gap-6">
              <Link
                href="/"
                className="text-sm font-medium text-gray-900 hover:text-gray-600 transition-colors"
              >
                Home
              </Link>
              <Link
                href="/insights"
                className="text-sm font-medium text-gray-600 hover:text-gray-900 transition-colors"
              >
                Insights
              </Link>
              <Link
                href="/research"
                className="text-sm font-medium text-gray-600 hover:text-gray-900 transition-colors"
              >
                Research
              </Link>
              <Link
                href="/technology"
                className="text-sm font-medium text-gray-600 hover:text-gray-900 transition-colors"
              >
                Technology
              </Link>
            </nav>
          </div>
          <div className="flex items-center gap-4">
            <div className="relative hidden md:block w-64">
              <input
                type="text"
                placeholder="Search..."
                className="w-full pl-9 pr-4 py-2 text-sm border border-gray-200 rounded-md focus:outline-none focus:ring-1 focus:ring-gray-400"
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
            </div>
            {token ? (
              <>
                <Link
                  href="/new-post"
                  className="px-4 py-2 text-sm font-medium text-white bg-gray-900 rounded-md hover:bg-gray-800 transition-colors"
                >
                  Create Post
                </Link>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Avatar className="h-8 w-8 cursor-pointer border border-gray-200">
                      <AvatarFallback className="bg-gray-100 text-gray-700">
                        <User className="h-4 w-4" />
                      </AvatarFallback>
                    </Avatar>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56">
                    <DropdownMenuItem>
                      <Link href={"/user/wallet"} className="flex w-full">
                        Wallet
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      {/* <span className="flex w-full">
                        {data?.toLocaleString()} SMT
                      </span> */}
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem>
                      <Disconnect token={token as string} setToken={setToken} />
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            ) : (
              <button className="px-4 py-2 text-sm font-medium text-white bg-gray-900 rounded-md hover:bg-gray-800 transition-colors">
                Sign In
              </button>
            )}
          </div>
        </div>
        <div className="h-10 flex items-center border-t border-gray-100">
          <nav className="flex items-center gap-6 text-xs">
            <Link
              href="/blockchain"
              className="font-medium text-gray-600 hover:text-gray-900 transition-colors"
            >
              Blockchain
            </Link>
            <Link
              href="/defi"
              className="font-medium text-gray-600 hover:text-gray-900 transition-colors"
            >
              DeFi
            </Link>
            <Link
              href="/nft"
              className="font-medium text-gray-600 hover:text-gray-900 transition-colors"
            >
              NFTs
            </Link>
            <Link
              href="/web3"
              className="font-medium text-gray-600 hover:text-gray-900 transition-colors"
            >
              Web3
            </Link>
            <Link
              href="/dao"
              className="font-medium text-gray-600 hover:text-gray-900 transition-colors"
            >
              DAOs
            </Link>
            <Link
              href="/metaverse"
              className="font-medium text-gray-600 hover:text-gray-900 transition-colors"
            >
              Metaverse
            </Link>
          </nav>
        </div>
      </div>
    </header>
  );
}
