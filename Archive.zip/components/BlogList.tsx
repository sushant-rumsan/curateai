"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { useEffect, useState } from "react";
import Image from "next/image";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Clock, BookmarkIcon, Search } from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { Navbar } from "./Navbar";

export type BlogPost = {
  id: string;
  title: string;
  content: string;
  imageUrl: string;
  contentHash: string;
  internal_id: string;
  tags: string[];
  date: string;
  score: number;
  userRating: number;
  aiRating: number;
  ipfsHash?: string;
};

// Dummy author names
const authorNames = [
  "Dr. Alex Johnson",
  "Taylor Smith, MBA",
  "Jordan Lee, CTO",
  "Casey Morgan, PhD",
  "Riley Zhang, Developer",
  "Quinn Davis, Analyst",
  "Morgan Freeman, Researcher",
  "Jamie Rodriguez, Engineer",
  "Avery Wilson, Strategist",
  "Dakota Chen, Consultant",
];

// Dummy descriptions
const dummyDescriptions = [
  "An analysis of blockchain technology's impact on enterprise systems and how organizations are implementing decentralized solutions to improve operational efficiency.",
  "Examining the strategic implications of artificial intelligence for business operations and the ethical considerations that must be addressed by leadership teams.",
  "A comprehensive review of Web3 technologies and their potential to transform digital infrastructure across various industry verticals.",
  "Investigating the market dynamics of non-fungible tokens and their implications for digital asset management in institutional portfolios.",
  "An evaluation of decentralized finance platforms and their disruptive potential within traditional banking and financial service sectors.",
  "Analyzing the implementation challenges of smart contract systems and strategies for effective integration with legacy business processes.",
  "A detailed assessment of blockchain's environmental impact and sustainable approaches to distributed ledger technology deployment.",
  "Exploring decentralized autonomous organizations as an emerging governance model for modern enterprises and their operational frameworks.",
  "A technical analysis of blockchain applications in supply chain management and their impact on transparency, efficiency, and risk mitigation.",
  "Examining the evolution of digital identity solutions in the Web3 ecosystem and implications for corporate security protocols.",
];

export default function BlogList({ blogPosts }: { blogPosts: BlogPost[] }) {
  const router = useRouter();
  const [searchQuery, setSearchQuery] = useState("");

  const searchParams = useSearchParams();
  const t = searchParams?.get("t");

  // Function to get a random placeholder image if no imageUrl is provided
  const getPlaceholderImage = () => {
    const placeholders = [
      "https://images.unsplash.com/photo-1526378722484-bd91ca387e72?q=80&w=1000",
      "https://images.unsplash.com/photo-1558655146-d09347e92766?q=80&w=1000",
      "https://images.unsplash.com/photo-1620641788421-7a1c342ea42e?q=80&w=1000",
      "https://images.unsplash.com/photo-1639762681057-408e52192e55?q=80&w=1000",
      "https://images.unsplash.com/photo-1639322537228-f710d846310a?q=80&w=1000",
    ];

    const index = Math.floor(Math.random() * placeholders.length);
    return placeholders[index];
  };

  // Function to get a dummy description
  const getDummyDescription = () => {
    const index = Math.floor(Math.random() * dummyDescriptions.length);
    return dummyDescriptions[index];
  };

  // Function to get a dummy author name
  const getDummyAuthorName = () => {
    const index = Math.floor(Math.random() * authorNames.length);
    return authorNames[index];
  };

  // Function to get read time
  const getReadTime = (content: string) => {
    const wordsPerMinute = 200;
    const words = content.split(/\s+/).length;
    return Math.max(1, Math.ceil(words / wordsPerMinute));
  };

  return (
    <div className="min-h-screen bg-white mt-8">
      <div className="flex">
        <main className="flex-1 max-w-[1280px] mx-auto px-4 pt-[100px]">
          <div className="grid grid-cols-1 lg:grid-cols-[1fr,320px] gap-10">
            <div>
              <header className="mb-10">
                <h1 className="text-3xl font-serif font-bold text-gray-900 mb-6">
                  Hot & Trending
                </h1>
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
                  <div className="relative w-full md:w-64">
                    <input
                      type="text"
                      placeholder="Search articles..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full pl-10 pr-4 py-2 text-sm border border-gray-200 rounded-md focus:outline-none focus:ring-1 focus:ring-gray-400"
                    />
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                  </div>
                </div>
                <Separator className="bg-gray-200" />
              </header>

              <div className="space-y-10">
                {/* Featured Article */}
                {blogPosts && blogPosts.length > 0 ? (
                  <article
                    className="cursor-pointer group"
                    onClick={() =>
                      router.push(
                        `/read/${blogPosts[0].ipfsHash}?cid=${blogPosts[0].internal_id}`
                      )
                    }
                  >
                    <div className="relative aspect-[16/9] mb-6">
                      <Image
                        src={blogPosts[0]?.imageUrl || getPlaceholderImage()}
                        alt={blogPosts[0]?.title || "Featured article"}
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div className="mb-3">
                      <span className="text-xs font-medium uppercase tracking-wider text-gray-500">
                        Featured
                      </span>
                    </div>
                    <h2 className="text-2xl md:text-3xl font-serif font-bold text-gray-900 mb-3 group-hover:text-gray-700 transition-colors">
                      {blogPosts[0]?.title ||
                        "The Strategic Implications of Blockchain Technology for Enterprise Systems"}
                    </h2>
                    <p className="text-base text-gray-600 mb-4 line-clamp-2">
                      {getDummyDescription()}
                    </p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Avatar className="h-8 w-8">
                          <AvatarImage src="/placeholder-user.jpg" />
                          <AvatarFallback className="bg-gray-200 text-gray-700 text-xs">
                            {(() => {
                              const name = getDummyAuthorName();
                              return name
                                .split(" ")
                                .map((n) => n[0])
                                .join("");
                            })()}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="text-sm font-medium text-gray-900">
                            {getDummyAuthorName()}
                          </p>
                          <p className="text-xs text-gray-500">
                            {new Date(
                              blogPosts[0]?.date || new Date()
                            ).toLocaleDateString(undefined, {
                              month: "long",
                              day: "numeric",
                              year: "numeric",
                            })}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 text-xs text-gray-500">
                        <Clock className="w-3.5 h-3.5" />
                        <span>
                          {getReadTime(
                            blogPosts[0]?.content ||
                              "Lorem ipsum dolor sit amet"
                          )}{" "}
                          min read
                        </span>
                      </div>
                    </div>
                  </article>
                ) : (
                  <article className="cursor-pointer group">
                    <div className="relative aspect-[16/9] mb-6">
                      <Image
                        src={getPlaceholderImage() || "/placeholder.svg"}
                        alt="Featured article"
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div className="mb-3">
                      <span className="text-xs font-medium uppercase tracking-wider text-gray-500">
                        Featured
                      </span>
                    </div>
                    <h2 className="text-2xl md:text-3xl font-serif font-bold text-gray-900 mb-3 group-hover:text-gray-700 transition-colors">
                      The Strategic Implications of Blockchain Technology for
                      Enterprise Systems
                    </h2>
                    <p className="text-base text-gray-600 mb-4 line-clamp-2">
                      {getDummyDescription()}
                    </p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Avatar className="h-8 w-8">
                          <AvatarImage src="/placeholder-user.jpg" />
                          <AvatarFallback className="bg-gray-200 text-gray-700 text-xs">
                            {(() => {
                              const name = getDummyAuthorName();
                              return name
                                .split(" ")
                                .map((n) => n[0])
                                .join("");
                            })()}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="text-sm font-medium text-gray-900">
                            {getDummyAuthorName()}
                          </p>
                          <p className="text-xs text-gray-500">
                            {new Date().toLocaleDateString(undefined, {
                              month: "long",
                              day: "numeric",
                              year: "numeric",
                            })}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 text-xs text-gray-500">
                        <Clock className="w-3.5 h-3.5" />
                        <span>5 min read</span>
                      </div>
                    </div>
                  </article>
                )}

                <Separator className="bg-gray-200" />

                {/* Regular Articles */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-10">
                  {blogPosts?.slice(1).map((post: BlogPost) => (
                    <article
                      key={post.id}
                      className="cursor-pointer group"
                      onClick={() =>
                        router.push(
                          `/read/${post.ipfsHash}?cid=${post.internal_id}`
                        )
                      }
                    >
                      <div className="relative aspect-[4/3] mb-4">
                        <Image
                          src={post?.imageUrl || getPlaceholderImage()}
                          alt={post?.title}
                          fill
                          className="object-cover"
                        />
                      </div>
                      <h2 className="text-xl font-serif font-bold text-gray-900 mb-2 group-hover:text-gray-700 transition-colors line-clamp-2">
                        {post.title ||
                          "Analyzing the Impact of Decentralized Technologies"}
                      </h2>
                      <p className="text-sm text-gray-600 mb-3 line-clamp-2">
                        {getDummyDescription()}
                      </p>

                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2">
                          <Avatar className="h-6 w-6">
                            <AvatarImage src="/placeholder-user.jpg" />
                            <AvatarFallback className="bg-gray-200 text-gray-700 text-xs">
                              {(() => {
                                const name = getDummyAuthorName();
                                return name
                                  .split(" ")
                                  .map((n) => n[0])
                                  .join("");
                              })()}
                            </AvatarFallback>
                          </Avatar>
                          <span className="text-xs font-medium text-gray-900">
                            {getDummyAuthorName()}
                          </span>
                        </div>
                        <div className="flex items-center gap-1 text-xs text-gray-500">
                          <Clock className="w-3 h-3" />
                          <span>
                            {getReadTime(
                              post.content || "Lorem ipsum dolor sit amet"
                            )}{" "}
                            min
                          </span>
                        </div>
                      </div>

                      <div className="flex flex-wrap gap-1.5">
                        {(post.tags || ["blockchain", "technology", "finance"])
                          .slice(0, 3)
                          .map((tag) => (
                            <span
                              key={tag}
                              className="text-xs text-gray-600 hover:text-gray-900 transition-colors"
                            >
                              #{tag}
                            </span>
                          ))}
                      </div>
                    </article>
                  ))}

                  {/* Dummy articles if no posts */}
                  {(!blogPosts || blogPosts.length <= 1) &&
                    Array(4)
                      .fill(0)
                      .map((_, index) => (
                        <article key={index} className="cursor-pointer group">
                          <div className="relative aspect-[4/3] mb-4">
                            <Image
                              src={getPlaceholderImage() || "/placeholder.svg"}
                              alt="Article thumbnail"
                              fill
                              className="object-cover"
                            />
                          </div>
                          <h2 className="text-xl font-serif font-bold text-gray-900 mb-2 group-hover:text-gray-700 transition-colors line-clamp-2">
                            {
                              [
                                "Analyzing the Impact of Decentralized Technologies",
                                "The Future of Smart Contracts in Enterprise Applications",
                                "Blockchain Solutions for Supply Chain Management",
                                "Regulatory Frameworks for Digital Assets",
                              ][index % 4]
                            }
                          </h2>
                          <p className="text-sm text-gray-600 mb-3 line-clamp-2">
                            {getDummyDescription()}
                          </p>

                          <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center gap-2">
                              <Avatar className="h-6 w-6">
                                <AvatarImage src="/placeholder-user.jpg" />
                                <AvatarFallback className="bg-gray-200 text-gray-700 text-xs">
                                  {(() => {
                                    const name = getDummyAuthorName();
                                    return name
                                      .split(" ")
                                      .map((n) => n[0])
                                      .join("");
                                  })()}
                                </AvatarFallback>
                              </Avatar>
                              <span className="text-xs font-medium text-gray-900">
                                {getDummyAuthorName()}
                              </span>
                            </div>
                            <div className="flex items-center gap-1 text-xs text-gray-500">
                              <Clock className="w-3 h-3" />
                              <span>{3 + index} min</span>
                            </div>
                          </div>

                          <div className="flex flex-wrap gap-1.5">
                            {[
                              ["blockchain", "technology", "finance"],
                              ["web3", "development", "security"],
                              ["defi", "cryptocurrency", "investment"],
                              ["nft", "digital-assets", "marketplace"],
                            ][index % 4].map((tag) => (
                              <span
                                key={tag}
                                className="text-xs text-gray-600 hover:text-gray-900 transition-colors"
                              >
                                #{tag}
                              </span>
                            ))}
                          </div>
                        </article>
                      ))}
                </div>
              </div>
            </div>

            <div className="hidden lg:block">
              <div className="sticky top-[100px]">
                <div className="bg-gray-50 p-6 mb-8">
                  <h3 className="text-lg font-serif font-bold text-gray-900 mb-4">
                    Newsletter
                  </h3>
                  <p className="text-sm text-gray-600 mb-4">
                    Stay informed with our weekly analysis of blockchain trends
                    and developments.
                  </p>
                  <div className="space-y-3">
                    <input
                      type="email"
                      placeholder="Your email address"
                      className="w-full px-3 py-2 text-sm border border-gray-200 rounded-md focus:outline-none focus:ring-1 focus:ring-gray-400"
                    />
                    <button className="w-full py-2 text-sm font-medium text-white bg-gray-900 rounded-md hover:bg-gray-800 transition-colors">
                      Subscribe
                    </button>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-serif font-bold text-gray-900 mb-4">
                    Latest
                  </h3>
                  <div className="space-y-4">
                    {[
                      "Blockchain Governance",
                      "Enterprise Adoption",
                      "Regulatory Frameworks",
                      "Sustainable Technology",
                      "Digital Assets",
                    ].map((topic) => (
                      <div
                        key={topic}
                        className="flex items-center gap-3 group cursor-pointer"
                      >
                        <div className="w-16 h-16 relative flex-shrink-0">
                          <Image
                            src={getPlaceholderImage() || "/placeholder.svg"}
                            alt={topic}
                            fill
                            className="object-cover"
                          />
                        </div>
                        <div>
                          <h4 className="text-sm font-medium text-gray-900 group-hover:text-gray-700 transition-colors">
                            {topic}
                          </h4>
                          <p className="text-xs text-gray-500">
                            {Math.floor(Math.random() * 20) + 5} articles
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
