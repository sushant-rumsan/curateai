
  export const tags = [
    "all",
    "blockchain",
    "ai",
    "nft",
    "crypto",
    "metaverse",
    "web3",
    "defi",
    "eth",
    "btc",
    "solana",
    "dao",
    "gamefi",
    "yield-farming",
    "smart-contracts",
    "layer2",
  ]