export const buttons = [
    { label: "Max", percentage: undefined },
    { label: "50%", percentage: 50 },
    { label: "20%", percentage: 20 },
    { label: "10%", percentage: 10 },
  ];