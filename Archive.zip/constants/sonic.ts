export const sonic_blaze_rpc =
  "https://sonic-blaze.g.alchemy.com/v2/qAEksW6pFqzHzh8WDvAC5CnhfBII8fJ-";
